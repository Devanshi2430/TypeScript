var mes = "Hello Guys..!!";
console.log(mes);
