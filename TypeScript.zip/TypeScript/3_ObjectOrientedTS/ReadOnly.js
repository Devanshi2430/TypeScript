var Person = /** @class */ (function () {
    function Person(birthDate) {
        this.birthDate = birthDate;
    }
    return Person;
}());
var person = new Person(new Date(1999, 12, 02));
console.log("Person Date: " + person.birthDate);
// person.birthDate = new Date(1999, 12, 02); // Compile error
